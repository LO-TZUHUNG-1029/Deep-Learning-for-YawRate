%% 虛擬感測器驗證與比較腳本
clear; clc;

% 1. 載入模型與標準化參數
load('YawRateVirtualSensor_Pro.mat'); % 確保這檔案在你的資料夾下

% 2. 讀取新數據 (包含實際 YawRate 用於驗證)
test_data = readmatrix("C:\Users\lojac\Desktop\NTU_RACING\tv試車數據\DeepLearningforYawRate\0322 _test\can_log_vcu_20260322_162727_decoded.csv");

% --- 提取特徵與標籤 ---
t_new      = (test_data(:,1) - test_data(1,1)) / 1000000;
yaw_actual = test_data(:,10) * pi / 180; % 實際值 (rad/s)
ax_new     = test_data(:,6) * 9.81;
ay_new     = test_data(:,7) * 9.81;
mtr_rl     = test_data(:,8);
mtr_rr     = test_data(:,9) * -1;
speed_new  = (mtr_rl + mtr_rr) * 2 * pi / 60 / 13.1 * 0.254/2;
steer_new  = test_data(:,5) * pi / 180;
accel_new  = test_data(:,3) / 100;

% 整合為輸入矩陣
X_test = [ax_new'; ay_new'; speed_new'; steer_new'; accel_new'];

% 3. 正規化與推論
X_test_norm = (X_test - muX) ./ sigmaX;
Y_pred_norm = predict(yawRateNet, {X_test_norm});

% 4. 反正規化還原單位
Y_pred_final = Y_pred_norm{1}' * sigmaY + muY; % 轉置回 Column 方便計算

% 5. 誤差分析 (關鍵指標)
error = yaw_actual - Y_pred_final; % 殘差
rmse = sqrt(mean(error.^2));      % 均方根誤差
correlation = corrcoef(yaw_actual, Y_pred_final);
R2 = correlation(1,2)^2;          % 決定係數 (愈接近 1 愈準)

%% 6. 數據清理與指標計算
% 確保數據中沒有 NaN 影響計算
idx = ~isnan(yaw_actual) & ~isnan(Y_pred_final); 

% 計算 RMSE
rmse_val = sqrt(mean((yaw_actual(idx) - Y_pred_final(idx)).^2));

% 計算 R-squared (R2)
y_bar = mean(yaw_actual(idx));
ss_res = sum((yaw_actual(idx) - Y_pred_final(idx)).^2);
ss_tot = sum((yaw_actual(idx) - y_bar).^2);
r2_val = 1 - (ss_res / ss_tot);

% 計算誤差序列
error_seq = yaw_actual - Y_pred_final;

%% 7. 繪圖比較
figure('Name', 'LSTM Virtual Sensor Performance', 'Color', 'w');

% 子圖 1: 曲線對比
subplot(2,1,1);
plot(t_new, yaw_actual, 'b', 'LineWidth', 1.2); hold on;
plot(t_new, Y_pred_final, 'r--', 'LineWidth', 1.2);
grid on;
ylabel('Yaw Rate (rad/s)');
legend('Actual (Sensor)', 'Predicted (LSTM)');
% 這裡用剛剛算好的 rmse_val 和 r2_val
title(['Performance: RMSE = ', num2str(rmse_val, '%.4f'), ' | R^2 = ', num2str(r2_val, '%.4f')]);

% 子圖 2: 誤差分布 (Residuals)
subplot(2,1,2);
plot(t_new, error_seq, 'Color', [0.5 0.5 0.5]);
grid on;
xlabel('Time (s)');
ylabel('Error (rad/s)');
title('Prediction Residuals (Actual - Predicted)');

%% 8. 散佈圖 (Correlation Plot)
figure('Name', 'Correlation Analysis', 'Color', 'w');
scatter(yaw_actual(idx), Y_pred_final(idx), 10, 'filled', 'MarkerFaceAlpha', 0.3);
hold on;
% 畫出理想的 45 度線
ref_line = [min(yaw_actual) max(yaw_actual)];
plot(ref_line, ref_line, 'r-', 'LineWidth', 2); 
xlabel('Actual Yaw Rate (rad/s)');
ylabel('Predicted Yaw Rate (rad/s)');
title(['Correlation (R^2 = ', num2str(r2_val, '%.4f'), ')']);
grid on;