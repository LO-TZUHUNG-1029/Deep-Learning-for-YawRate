clc; clear;

%% 1. 定義檔案清單 (把你的前四筆路徑填進去)
fileList = { ...
    "C:\Users\lojac\Desktop\NTU_RACING\tv試車數據\DeepLearningforYawRate\0322 _test\can_log_vcu_20260322_161755_decoded.csv"
    "C:\Users\lojac\Desktop\NTU_RACING\tv試車數據\DeepLearningforYawRate\0322 _test\can_log_vcu_20260322_162117_decoded.csv"
    "C:\Users\lojac\Desktop\NTU_RACING\tv試車數據\DeepLearningforYawRate\0322 _test\can_log_vcu_20260322_162445_decoded.csv"
};

X_train_cells = {};
Y_train_cells = {};

% 用來計算全局標準化參數的暫存器
X_all_combined = [];
Y_all_combined = [];

%% 2. 迴圈讀取並處理每一筆數據
for i = 1:length(fileList)
    fprintf('正在讀取第 %d 筆數據...\n', i);
    raw_data = readmatrix(fileList{i});
    
    % --- 處理缺失值 (NaN) ---
    raw_data = fillmissing(raw_data, 'linear');
    raw_data(any(isnan(raw_data), 2), :) = []; % 剔除剩餘無法插值的 NaN
    
    % --- 提取特徵 (跟你原本的邏輯一樣) ---
    % 假設欄位順序沒變
    ax    = raw_data(:,6) * 9.81;
    ay    = raw_data(:,7) * 9.81;
    mtr_rl = raw_data(:,8);
    mtr_rr = raw_data(:,9) * -1;
    speed = (mtr_rl + mtr_rr) * 2 * pi / 60 / 13.1 * 0.254/2;
    steer = raw_data(:,5) * pi / 180;
    accel = raw_data(:,3) / 100;
    yaw_actual = raw_data(:,10) * pi / 180;
    
    % 整合為矩陣 [5 x N]
    X_tmp = [ax'; ay'; speed'; steer'; accel'];
    Y_tmp = yaw_actual';
    
    % 存入 Cell 陣列
    X_train_cells{i} = X_tmp;
    Y_train_cells{i} = Y_tmp;
    
    % 累積數據以便後續計算全局 mu/sigma
    X_all_combined = [X_all_combined, X_tmp];
    Y_all_combined = [Y_all_combined, Y_tmp];
end

%% 3. 全局標準化 (關鍵：所有數據共用同一套比例尺)
[~, muX, sigmaX] = zscore(X_all_combined, 0, 2);
[~, muY, sigmaY] = zscore(Y_all_combined, 0, 2);

% 對每一組 Cell 進行標準化處理
for i = 1:length(X_train_cells)
    X_train_cells{i} = (X_train_cells{i} - muX) ./ sigmaX;
    Y_train_cells{i} = (Y_train_cells{i} - muY) ./ sigmaY;
end

%% 4. 構建 LSTM 架構 (與你原本的一樣)
numFeatures = 5;
numHiddenUnits = 64;
layers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits, 'OutputMode', 'sequence')
    fullyConnectedLayer(64)
    reluLayer()
    fullyConnectedLayer(32)
    reluLayer()
    fullyConnectedLayer(16)
    reluLayer()
    dropoutLayer(0.2)
    fullyConnectedLayer(1)
    regressionLayer];

%% 5. 訓練設定
options = trainingOptions('adam', ...
    'MaxEpochs', 200, ...
    'GradientThreshold', 1, ...
    'InitialLearnRate', 0.005, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 50, ...
    'LearnRateDropFactor', 0.5, ...
    'Plots', 'training-progress', ...
    'Verbose', false);

%% 6. 開始訓練 (輸入多個序列)
yawRateNet = trainNetwork(X_train_cells, Y_train_cells, layers, options);

%% 7. 儲存這組「最強權重」
save('YawRateVirtualSensor_Pro.mat', 'yawRateNet', 'muX', 'sigmaX', 'muY', 'sigmaY');
fprintf('多檔案訓練完成！模型已儲存。\n');